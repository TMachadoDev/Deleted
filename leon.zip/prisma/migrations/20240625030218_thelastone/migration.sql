-- DropIndex
DROP INDEX "Bans_player_key";

-- DropIndex
DROP INDEX "DeletedPlayers_player_key";

-- DropIndex
DROP INDEX "Fdp_player_key";
